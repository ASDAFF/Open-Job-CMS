<?php
define('OJC_VERSION_NAME', 'Open Job CMS');
define('OJC_VERSION', 'V1.0.0');

define('ROOT_PATH', dirname(__FILE__));
//define('IS_DEMO', true);

define('ALREADY_INSTALL_FILE', ROOT_PATH . DIRECTORY_SEPARATOR . 'protected' . DIRECTORY_SEPARATOR
    . 'runtime' . DIRECTORY_SEPARATOR . 'already_install');